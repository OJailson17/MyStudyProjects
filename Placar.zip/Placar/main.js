function ClickMais() {
  var placar =parseInt( document.getElementById('score').value);
  document.getElementById('score').value = placar + 1;
}

function ClickMenos() {
  var placar = parseInt(document.getElementById('score').value);
  document.getElementById('score').value = placar - 1;
}